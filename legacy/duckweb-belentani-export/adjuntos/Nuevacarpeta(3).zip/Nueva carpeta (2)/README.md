# NOIA CORE ENGINE v3.0

> Motor de prospección B2B automatizado — de lead crudo a email enviado en <3 minutos.

```
Apify/n8n → POST /api/v1/leads/ingest
               │
               ▼
          FastAPI (rate-limited, HMAC-verified)
               │
               ▼
         Redis (Celery queue)
               │
               ▼
         Worker: process_lead_task
          ├── 1. Upsert (idempotente)
          ├── 2. Scan forense (PageSpeed → HTTP fallback)
          ├── 3. Generar email (CrewAI/GPT-4 → template fallback)
          └── 4. Enviar (SendGrid → Resend → Mailgun)
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        External Sources                         │
│                   Apify scrapers / n8n workflows                │
└─────────────────────────┬───────────────────────────────────────┘
                          │ POST /api/v1/leads/ingest
                          │ HMAC-SHA256 signed
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                     FastAPI (app/main.py)                       │
│  • CORS middleware (strict in production)                       │
│  • Security headers (HSTS, CSP, X-Frame-Options)               │
│  • HMAC webhook verification                                    │
│  • Rate limiting (slowapi + Redis, 30/min per IP)              │
│  • Pydantic v2 input validation                                 │
│  • Domain dedup check                                           │
└─────────────────────────┬───────────────────────────────────────┘
                          │ process_lead_task.delay(data)
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                   Redis (Celery broker + results)               │
│  • Rate limit store                                             │
│  • Task queue                                                   │
│  • Result cache (24h TTL)                                       │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                Celery Worker (app/tasks.py)                     │
│                                                                 │
│  1. Upsert lead (idempotent via domain_hash SHA-256)           │
│  2. Idempotency guard (skip suppressed/contacted)              │
│  3. Forensic analysis                                           │
│     └── FallbackChain: PageSpeed API → HTTP header scan        │
│  4. Pain point detection                                        │
│     └── SSL valid, mobile score, security headers, server leak │
│  5. Email generation                                            │
│     └── CrewAI/GPT-4 (optional) → Spanish template fallback    │
│  6. Outreach delivery                                           │
│     └── FallbackChain: SendGrid → Resend → Mailgun            │
│  7. Status update in PostgreSQL                                 │
└─────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    PostgreSQL (leads table)                     │
│  • Encrypted email (Fernet AES-128-CBC + HMAC)                 │
│  • Domain hash for dedup                                        │
│  • Status state machine: NEW→SCANNING→ANALYZED→CONTACTED       │
│  • SSL/mobile scores for analytics                              │
└─────────────────────────────────────────────────────────────────┘
```

### Project Structure

```
noia-core-v3/
├── app/
│   ├── main.py                 # FastAPI entry point + endpoints
│   ├── config.py               # Pydantic BaseSettings (env validation)
│   ├── database.py             # SQLAlchemy engine + Redis client
│   ├── models.py               # Lead model (encrypted email at rest)
│   ├── schemas.py              # Pydantic v2 I/O schemas
│   ├── tasks.py                # Celery task definitions
│   ├── core/
│   │   ├── fallback_engine.py  # FallbackChain + circuit breaker
│   │   └── logging_config.py   # Structured JSON logging + Sentry
│   ├── security/
│   │   ├── encryption.py       # MultiFernet (AES-128-CBC + key rotation)
│   │   └── validators.py       # SSRF protection (DNS + IP blocking)
│   ├── providers/
│   │   ├── forensic_providers.py  # PageSpeed API + HTTP fallback
│   │   └── outreach_providers.py  # SendGrid + Resend + Mailgun
│   └── services/
│       ├── forensic_service.py    # Website analysis orchestrator
│       └── outreach_service.py    # Cold email delivery + pain detection
├── migrations/
│   └── versions/
│       └── 001_initial.py      # Alembic: leads table
├── tests/
│   └── test_core.py            # pytest suite
├── .env.example                # Environment variable template
├── requirements.txt            # Pinned Python dependencies
├── Dockerfile                  # Multi-stage (builder + runtime)
├── docker-compose.yml          # Local dev stack (5 services)
├── railway.json                # Railway deploy config
├── Procfile                    # Railway/Heroku fallback
├── DEPLOY.md                   # Step-by-step Railway deployment
└── README.md                   # This file
```

## Stack de coste mínimo

| Componente | Servicio | Coste |
|---|---|---|
| API + Worker | Railway Hobby | ~$5/mes |
| PostgreSQL | Railway PostgreSQL | ~$1/mes |
| Redis | Railway Redis | ~$0 (incluido) |
| Email (100/día) | SendGrid free | $0 |
| Email overflow | Resend + Mailgun free | $0 |
| PageSpeed API | Google Cloud free | $0 |
| Monitor errores | Sentry free | $0 |
| **Total** | | **~$6/mes** |

## Capas de seguridad

1. **HMAC-SHA256** en webhooks — imposible falsificar requests de Apify/n8n
2. **Rate limiting Redis** — 30 req/min por IP, persiste entre reinicios
3. **Validación SSRF** — bloquea 169.254.x.x, 10.x, 127.x antes de cualquier HTTP
4. **Fernet AES-128-CBC + HMAC** — emails cifrados en BD, nunca en texto plano
5. **Circuit breaker** — si un proveedor cae, no se acumulan timeouts
6. **Security headers** — HSTS, CSP, X-Frame-Options, etc.
7. **GDPR/RGPD** — unsubscribe en 1 clic, respuesta idéntica (no filtra si existe)
8. **Non-root Docker** — proceso corre como usuario `noia`, no como root
9. **Pydantic v2** — validación estricta de todos los inputs antes de tocar la BD
10. **Sentry** — cada excepción con stack trace completo en producción

## Auto-resiliencia

- **FallbackChain** con circuit breaker por proveedor (60s cooldown)
- **Celery autoretry** con backoff exponencial (hasta 3 intentos, max 5 min)
- **task_acks_late=True** — nunca se pierde un task si el worker cae mid-execution
- **pool_pre_ping** — detecta conexiones BD muertas antes de usarlas
- **health endpoint** — sonda DB y Redis por separado, retorna 503 si alguno falla
- **worker_max_tasks_per_child=50** — restart automático para prevenir memory leaks

## API Documentation

### Endpoints

| Method | Path | Rate Limit | Auth | Description |
|---|---|---|---|---|
| `POST` | `/api/v1/leads/ingest` | 30/min | HMAC-SHA256 | Ingest leads from Apify/n8n |
| `GET` | `/api/v1/tasks/{task_id}` | 60/min | None | Poll Celery task status |
| `GET` | `/api/v1/unsubscribe` | 20/min | None | GDPR unsubscribe (constant-time) |
| `GET` | `/health` | None | None | Composite DB + Redis healthcheck |

Swagger docs available at `/docs` in development only.

### POST /api/v1/leads/ingest

Receives leads from Apify/n8n and enqueues for async processing. Returns in <50ms.

**Headers:**
- `Content-Type: application/json`
- `X-Webhook-Signature: <hex>` — HMAC-SHA256 of request body using `WEBHOOK_SECRET`

**Request body:**
```json
{
  "business_name": "Acme Corp",
  "website": "https://acme.com",
  "email": "info@acme.com",
  "sector": "technology",
  "zone": "Barcelona"
}
```

**Response (202 Accepted):**
```json
{
  "message": "Lead enqueued for analysis",
  "task_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
}
```

**Duplicate response (200):**
```json
{
  "message": "Lead already processed",
  "task_id": null,
  "lead_id": "existing-lead-uuid"
}
```

### GET /api/v1/tasks/{task_id}

Poll Celery task status. Used by n8n until `status == SUCCESS`.

**Response:**
```json
{
  "task_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "status": "SUCCESS",
  "result": {
    "status": "contacted",
    "lead_id": "uuid-here"
  }
}
```

**Status values:** `PENDING`, `STARTED`, `SUCCESS`, `FAILURE`, `RETRY`

### GET /api/v1/unsubscribe

GDPR-compliant unsubscribe. Always returns the same response — never reveals whether the email exists.

**Query params:** `email` (string)

**Response:**
```json
{
  "message": "Email permanently suppressed. You will not receive further messages."
}
```

### GET /health

Composite healthcheck for Docker / Uptime Robot / Railway. Returns 200 only when BOTH DB and Redis are reachable.

**Response (200):**
```json
{
  "status": "ok",
  "checks": {
    "db": "ok",
    "redis": "ok"
  }
}
```

**Response (503):**
```json
{
  "status": "degraded",
  "checks": {
    "db": "ok",
    "redis": "error: Connection refused"
  }
}
```

## Inicio rápido (desarrollo local)

```bash
# 1. Clonar y configurar
cp .env.example .env
# Editar .env con tus keys

# 2. Levantar servicios
docker-compose up -d db redis

# 3. Instalar dependencias
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 4. Migrar BD
alembic upgrade head

# 5. Arrancar API
uvicorn app.main:app --reload

# 6. Arrancar worker (en otra terminal)
celery -A app.tasks worker --loglevel=info

# 7. Probar
curl -X POST http://localhost:8000/api/v1/leads/ingest \
  -H "Content-Type: application/json" \
  -d '{"business_name":"Test","website":"https://example.com","email":"test@example.com"}'
```

## Despliegue en Railway

See [DEPLOY.md](DEPLOY.md) for the full step-by-step guide.

```bash
# 1. Instalar CLI
npm install -g @railway/cli && railway login

# 2. Crear proyecto
railway new noia-core

# 3. Añadir servicios
railway add --plugin postgresql
railway add --plugin redis

# 4. Configurar variables (copia de .env.example)
railway variables set APP_ENV=production APP_DOMAIN=tu-dominio.com ...

# 5. Desplegar
railway up

# 6. Añadir worker separado
railway service new worker
railway variables set RAILWAY_START_COMMAND="celery -A app.tasks worker --loglevel=info --concurrency=2" --service worker
```

## Tests

```bash
# Install dev dependencies
pip install pytest pytest-asyncio

# Run tests
pytest tests/ -v
```

## Variables de entorno obligatorias

| Variable | Descripción |
|---|---|
| `SECRET_KEY` | Clave aleatoria para JWT |
| `DATABASE_URL` | PostgreSQL en producción |
| `REDIS_URL` | Redis para Celery |
| `VAULT_FERNET_KEY` | Clave de cifrado PII — NUNCA perder |
| `WEBHOOK_SECRET` | Secreto compartido con Apify/n8n |

Al menos un proveedor de email: `SENDGRID_API_KEY`, `RESEND_API_KEY`, o `MAILGUN_API_KEY`.

See [.env.example](.env.example) for the complete list with descriptions.

## Extensión con CrewAI (emails con IA)

1. Descomentar `crewai` y `openai` en `requirements.txt`
2. Añadir `OPENAI_API_KEY` en `.env`
3. Crear `app/agents/crew_definition.py` y `app/agents/crew_tasks.py`
4. El sistema los detecta automáticamente y usa IA si están presentes

## Arquitectura de crecimiento

El sistema está diseñado para crecer sin cambiar el código:
- **Más volumen** → añadir workers (`railway scale worker=3`)
- **Más proveedores** → añadir función a `FallbackChain`, un `import`, listo
- **Más análisis** → añadir campo en `models.py` + provider en `forensic_providers.py`
- **Multi-idioma** → pasar `locale` en el lead, el builder adapta el email

## License

Proprietary — NOIA CORE v3.0
